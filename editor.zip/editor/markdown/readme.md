# h1 title

h1 title
===

## h2 title

h2 title
---

###### h6 title


hello.  
*hello. hello. hello.* hello. hello. hello. hello. hello. hello. hello. _hello. hello. hello._


---

***

___


> quote. quote. quote. quote. quote. quote. quote. quote. quote. quote. quote. quote. quote. quote.

- - -

hello. **hello. hello. hello.** hello. hello. hello. hello. hello. hello. hello. __hello. hello. hello.__


- item1
- item2

    hello. hello. hello. hello. hello. hello. hello. hello. hello. hello. hello. hello.


- item3
+ item4
* item5

---

1. item1
2. item2
3. item3

---

1. item1
1. item2
1. item2.5
1. item3

<http://dotinstall.com>

[dotinstall](http://dotinstall.com)

[dotinstall](http://dotinstall.com "this is dotinstall!")

```
function x() {
  return x;
}
```

    function x() {
      return x;
    }

この場合、`return x;`はどこに書くのでしょうか？
